#include <bits/wordsize.h>

#if __WORDSIZE == 32
# include "version-32.h"
#elif __WORDSIZE == 64
# include "version-64.h"
#else
# error "unexpected value for __WORDSIZE macro"
#endif
